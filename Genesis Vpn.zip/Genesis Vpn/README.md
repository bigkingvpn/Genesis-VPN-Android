# GenesisVpn

Genesis, total free VPN client.
Easy to use, one click to connecting VPN.
Unlimited bandwidth and unlimited free trial time.

* Protect your privacy, keep you safe from 3rd party tracking
* Unblock geographically restricted websites
* No registration required, no settings required
* No speed limitation, no bandwidth limitation
* One-click to connecting VPN
* No root access needed
* Encrypts your internet traffic
* Top server speed & reliability
* Using most secure VPN solution

The app provides 20 days trial. After 20 days, you can use the app for 60 minutes each session. When session ends, a simple reconnect will get another session.
