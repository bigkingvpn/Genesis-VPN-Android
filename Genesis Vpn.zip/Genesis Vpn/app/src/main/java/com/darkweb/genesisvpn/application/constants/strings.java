package com.darkweb.genesisvpn.application.constants;

public class strings
{
    /*SHARE APPLICATION*/

    public static String sh_type = "text/plain";
    public static String sh_title = "Hi! Check out this Awesome App";
    public static String sh_subject = "Hi! Check out this Awesome App";
    public static String sh_desc = "Genesis VPN | Ultimate Security | http://play.google.com/store/apps/details?id";

    /*CONTACT*/

    public static String co_type = "mailto:";

    /*GENERIC*/

    public static String emptySTR = "";

    /*HOME BUTTON*/
    public static String goText = "GO";
    public static String connectingText = "Connecting";
    public static String connectedText = "Connected";

}
