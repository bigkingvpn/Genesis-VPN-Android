package com.darkweb.genesisvpn.application.constants;

public class messages
{
    /*ROTATING ANIMATION*/

    public final static int CIRCULAR_GROW_STARTED = 1;
    public final static int CIRCULAR_GROW_FINISH = 2;


}
