package com.darkweb.genesisvpn.application.constants;

public class enums {

    public static enum connection_status
    {
        unconnected, connecting, connected;
    }

}
